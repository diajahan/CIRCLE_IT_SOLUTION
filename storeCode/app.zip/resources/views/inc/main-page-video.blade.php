<section  class="about">
    <div class="container">
      <div class="section-header">
        <h1 style="font-size:4vw; font-weight:bold; color:#DA83A5;">সন্তানের অতিরিক্ত মোবাইল  <br>দেখা নিয়ে চিন্তিত ?</h1>
        <p  class="text-dark mt-3" style="font-size:2vw; font-weight:bold;">আসুন ওদের হাতে তুলে দেই ফান ক্রাফট বক্স
        </p>
      </div>
      <div class="ratio ratio-4x3" style="margin-bottom:3%;">
<iframe width="560" height="315" src="https://www.youtube.com/embed/5lfp3NmY6ts?rel=0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

      </div>
    </div>
  </section><!-- End About Section -->

<?php $__env->startSection('content'); ?>
<div class="product-section" style="margin-top:7%;">
    <div class="container-fluid mb-5">
    <div class="row grid-row p-2">
      <p  class="py-5 video-grid-view-p" style="font-weight:bold;">
       <a href="<?php echo e(url('/')); ?>">Home</a>&nbsp;/&nbsp;<a href="<?php echo e(url('/picture-tutorials')); ?>">picture Tutorials</a>
       </p>
       
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-3 col-sm-6 col-12 mb-2">
                <a href="<?php echo e(url('view-blog/'.$blog->id)); ?>">
                    <div class="card" style="min-height:250px; width:100%;">
                        <div class="card-body ml-2 text-center">
                            <img  class="card-img-top" alt="..." 
                                src="<?php echo e(asset('assets/img/blog-images/'.$blog->blog_cover_image.'?v=1.1')); ?>">
                                    <p class="card-title mt-3" style="min-height:40px; font-weight:bold; font-size:13px;"><?php echo e($blog->title); ?></p>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <div class="row mt-5 pagination-row" >
                <div class="col-lg-5 col-md-4 col-sm-3 col-3"></div>
                    <div class="col-lg-4 col-md-4 col-sm-9 col-9 pagination-col">
                        <?php echo e($blogs->onEachSide(3)->links()); ?>

                    </div>
                <div class="col-lg-3 col-md-4 col-sm-2 col-12"></div>
            </div>            

      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/view-picture-tutorials.blade.php ENDPATH**/ ?>
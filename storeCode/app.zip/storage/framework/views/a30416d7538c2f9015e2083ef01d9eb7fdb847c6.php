<nav class="bg-custom main-header navbar navbar-expand navbar-dark navbar-light">
    <ul class="navbar-nav">
    <li class="nav-item">
    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
    </ul>

    <ul class="navbar-nav ml-auto">
		<li class="dropdown user user-menu open">
            <a href="#" id="user-name-hover" class="text-decoration-none" data-toggle="dropdown" aria-expanded="true">
              <img src="<?php echo e(asset('backend/dist/img/profile.jpg')); ?>" class="user-image" alt="User Image">
              
            </a>
            <ul class="dropdown-menu" id="user-logout">
              <!-- User image -->
              <li class="user-header" id="user-logout-Li">
                <img src="<?php echo e(asset('backend/dist/img/profile.jpg')); ?>" class="img-circle user-image" alt="User Image">
                <p class="text-white" style="font-size:20px;">
                    
                
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">

                </div>
                <div class="pull-right cutom-hover">
                <a href="<?php echo e(url('/logout')); ?>"  class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>


    </ul>
    </nav>
<?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/Backend/layouts/inc/header.blade.php ENDPATH**/ ?>
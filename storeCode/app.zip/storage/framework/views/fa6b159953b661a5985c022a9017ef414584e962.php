
<footer class="main-footer">
    <strong>Copyright &copy;<a href="#">2022 bdclearence </a></strong>
    
    <div class="float-right d-none d-sm-inline-block">
    <b>All rights reserved</b> 
    </div>
    </footer>
    
    <aside class="control-sidebar control-sidebar-dark">
    
    </aside>
    
    </div>
    
    <?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/Backend/layouts/inc/footer.blade.php ENDPATH**/ ?>
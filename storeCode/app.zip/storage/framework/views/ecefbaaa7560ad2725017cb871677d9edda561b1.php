<section id="hero" class="hero d-flex align-items-center section-bg" style="">
    <div class="container mb-5" style="">
      <div class="row justify-content-between gy-5" >
        <div class="hero-book-a-table-div col-lg-10 order-2 order-lg-1 d-flex flex-column justify-content-center align-items-center align-items-lg-start text-center text-lg-start">
            <h2 style="" class="text-dark" style="font-size:4vw;"></h2>
            <p  class="text-dark" style="font-size:3vw; font-weight:bold;">
            </p>

          <div class="d-flex" data-aos="" data-aos-delay="200">
            
            
          </div>
        </div>
      </div>
    </div>
  </section><!-- End Hero Section -->
<?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/inc/hero-section.blade.php ENDPATH**/ ?>
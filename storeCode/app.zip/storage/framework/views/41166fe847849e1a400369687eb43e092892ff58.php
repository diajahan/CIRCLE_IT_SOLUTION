<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.hero-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="main">
<!-- ======= Main Video Section ======= -->
<?php echo $__env->make('inc.main-page-video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======= Category Section ======= -->
<?php echo $__env->make('inc.top-categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======= Our Packages Section ======= -->
<?php echo $__env->make('inc.events-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======= About Us Section ======= -->
<?php echo $__env->make('inc.about-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======= Gurdian Reviews Section ======= -->
<?php echo $__env->make('inc.customer-reviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bdcleqiq/bogganbox.bdclearance.com/resources/views/frontend-content.blade.php ENDPATH**/ ?>
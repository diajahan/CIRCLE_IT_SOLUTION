<?php $__env->startSection('content'); ?>
<div class="container ml-5 mb-5" style="margin-top:15%;">
    <h3 class="text-danger" style="font-weight:bold; margin-top:14%;">Privacy Policy _ Fun Craft by Taiba</h3>
    <p>Last updated: January 12, 2023</p>
    <p class="" style="text-align:justify;">This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You.</p>
    <p class="" style="text-align:justify;">We use Your Personal data to provide and improve the Service. By using the Service, You agree to the collection and use of information in accordance with this Privacy Policy. This Privacy Policy has been created with the help of the Privacy Policy Generator.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/privacy-policy.blade.php ENDPATH**/ ?>
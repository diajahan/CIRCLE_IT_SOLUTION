  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center" style="background:#fff; border-bottom:#DA83A5 2px solid;">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a href="<?php echo e(url('/')); ?>" class="nav-logo" style="margin-left:3%;">
        <img class="logo nav-logo-img" height="100" width="100" style="" src="<?php echo e(asset('assets/img/logo-png.png')); ?>">
      </a>

      <nav id="navbar" class="navbar">
        <ul>
            <li><a href="<?php echo e(url('/')); ?>" class="text-dark " style="font-size:12px;">Home</a></li>
            <li><a href="<?php echo e(url('/submite-your-own-craft')); ?>" class="text-dark" style="font-size:12px;">Submit Your Own Craft</a></li>
            <li><a href="<?php echo e(url('/picture-tutorials')); ?>" class="text-dark" style="font-size:12px;">Picture Tutorials</a></li>
             <li><a href="<?php echo e(url('/video-tutorials')); ?>" class="text-dark" style="font-size:12px;">Video Tutorials</a></li>
             <li><a href="#" class="text-dark" style="font-size:12px;">Wholesale</a></li>
            <li><a href="#about" class="text-dark" style="font-size:12px;">About Us</a></li>
          </ul>
      </nav><!-- .navbar -->
      <span>
        <a href="<?php echo e(url('/view-cart')); ?>" class="">

        <i class="fa fa-cart-plus fa-2x PositionCartCount" aria-hidden="true" style="color:#DA83A5;">&nbsp;&nbsp;&nbsp;&nbsp;
        </i>
        <span class="cart-count badge rounded-pill PositionCartSpan"
        style="background:#DA83A5;">0</span>
    </a>
    </span>
      <a class="btn-book-a-table" href="<?php echo e(url('/view-products')); ?>"
      style="font-size:22px; font-weight:bold;">Products</a>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
    </div>
  </header><!-- End Header -->
<?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/inc/header.blade.php ENDPATH**/ ?>
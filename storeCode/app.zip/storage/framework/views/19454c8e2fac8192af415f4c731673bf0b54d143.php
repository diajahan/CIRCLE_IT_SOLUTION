<section id="gallery" class="gallery section-bg">
    <div class="container-fluid" data-aos="fade-up">

      <div class="section-header">
        <h2 style="font-size:2vw; font-weight:bold; color:#000;">Top Categories</h2>
      </div>

      <div class="gallery-slider swiper">
        <div class="swiper-wrapper align-items-center">
            <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="<?php echo e(asset('assets/img/category-images/'.$cate->image)); ?>">
                <a href="<?php echo e(url('view-cate-products/'.$cate->id)); ?>"><img src="<?php echo e(asset('assets/img/category-images/'.$cate->image)); ?>" class="img-fluid" alt=""></a></a></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="swiper-pagination"></div>
      </div>

    </div>
  </section><!-- End Gallery Section -->
<?php /**PATH /home/bdcleqiq/bogganbox.bdclearance.com/resources/views/inc/top-categories.blade.php ENDPATH**/ ?>
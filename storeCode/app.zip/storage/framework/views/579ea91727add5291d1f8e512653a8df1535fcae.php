<div class="modal fade" id="updateproduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 650px!important;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">Update Product</span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5">
                
                <form action="<?php echo e(url('update-product/'.$product->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group row">
                        <input type="hidden" name="no-status-order-id" id="no-status-order-id">
                        <label for="" class="col-sm-4 col-form-label">Product Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control"  name ="product_name" value="<?php echo e($product->name); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="position" class="col-sm-4 control-label">Slect Category </label>
                        <div class="col-sm-8">
                            
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="sku" class="col-sm-4 col-form-label">SKU</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name ="sku" value="<?php echo e($product->sku); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="advancePayment" class="col-sm-4 col-form-label">Slug</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name ="slug" value="<?php echo e($product->slug); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Small Description</label>
                        <div class="col-sm-8">
                                <textarea name="smallDescription"  rows="1" class="form-control"><?php echo e($product->small_description); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Description</label>
                        <div class="col-sm-8">
                                <textarea name="description"  id="summernote" rows="1" class="form-control"><?php echo e($product->description); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Original Price</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name ="original_price" value="<?php echo e($product->original_price); ?>">
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Selling Price</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name ="selling_price" value="<?php echo e($product->selling_price); ?>">
                        </div>
                    </div>

                   <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Price to set offer</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name ="offer_price" value="<?php echo e($product->	offer_price); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Deal Start Date</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name ="deal-start-date" value="<?php echo e($product->deal_start_date); ?>">
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Deal End Date</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name ="deal-end-date" value="<?php echo e($product->deal_end_date); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Tax</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name ="tax" value="<?php echo e($product->tax); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Quantity</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name ="qty" value="<?php echo e($product->qty); ?>">
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Status</label>
                        <div class="col-sm-8" >
                            <select class="form-control" name="status" id="status">
                                <option value="<?php echo e($product->status); ?>" slected="">
                                    <?php if($product->status == 1): ?>
                                        Active
                                       <?php else: ?>
                                        Deactive
                                       <?php endif; ?>
                                    </option>
                                <option value="1">Active</option>
                                   <option value="0">Deactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Deal</label>
                        <div class="col-sm-8" >
                            <select class="form-control" name="deal" id="deal">
                                <option value="<?php echo e($product->deal); ?>" slected="">
                                <?php if($product->deal == 1): ?>
                                    Active
                                   <?php else: ?>
                                    Deactive
                                   <?php endif; ?>
                                </option>
                                <option value="1" >Active</option>
                                   <option value="0">Deactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Meta title</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="meta_title" value="<?php echo e($product->meta_title); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Meta Description</label>
                        <div class="col-sm-8">
                            <textarea name="meta_description"  rows="1" class="form-control"><?php echo e($product->meta_description); ?></textarea>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Meta Keywords</label>
                        <div class="col-sm-8">
                            <textarea name="meta_keyword"  rows="1" class="form-control"><?php echo e($product->meta_keyword); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label">Choose Image</label>
                        <div class="col-sm-8">
                        <input name ="image" type="file" class="form-control">
                            </div>
                        </div>

                   <div class="row mt-2 mb-2">
                        <label for="" class="col-sm-4 col-form-label">Image</label>
                        <div class="col-sm-8">
                    <?php if($product->image): ?>
                    <img src="<?php echo e(asset('assets/images/'.$product->image)); ?>" class="cate-img" alt="product image" height="60" width="60">
                    <?php endif; ?>
                </div>
            </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Update Order</button>
                    </div>
                </form>




            </div>
        </div>
    </div>
<?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/Backend/layouts/inc/update-product-modal.blade.php ENDPATH**/ ?>
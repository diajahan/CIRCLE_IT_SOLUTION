<?php $__env->startSection('content'); ?>
<div class="product-section" style="margin-top:7%;">
    <div class="container mb-5">
    <div class="row p-5" style="">
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
     <h2 class="ml-5 text-center text-dark py-2" style=""><?php echo e($blog->title); ?></h2>
    <p class="py-4"><?php echo e($blog['intro']); ?></p>
    <strong class="py-4 mt-4">যা যা লাগবে </strong>
        <?php echo $blog->equipments; ?>

        <div class="ml-5 text-center blog-page-multi-image py-4">
        
        </div>
    <strong class="py-4">যেভাবে তৈরি করবে</strong>
    <?php $__currentLoopData = $blog_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog_cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="mt-3">
            <?php echo $blog_cont->content; ?>

        </p>
        <div class="ml-5 text-center blog-page-multi-image">
            <?php $__currentLoopData = $blog_cont->blogImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img
            src="<?php echo e(asset('assets/img/blog-images/'.$image->image)); ?>" alt="" class="mt-5">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/Blog/view-single-blog.blade.php ENDPATH**/ ?>
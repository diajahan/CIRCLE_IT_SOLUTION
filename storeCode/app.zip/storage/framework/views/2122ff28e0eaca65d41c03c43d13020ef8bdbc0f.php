<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Video Tutorials</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <i class="nav-icon fas fa-tachometer-alt mr-2"></i>Home
                        </li>
                        <li class="breadcrumb-item">Video Tutorials</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        
                
                <div class="card">
                    <div class="card-header bg-white text-white">
                        <button type="button" class="btn btn-info mb-2" data-toggle="modal"
                            data-target="#add-video">
                            <i class="fa fa-plus-circle"></i>&nbsp;&nbsp;Add Video</button>
                    </div>
                    <!-- /.card-header -->

                    <div class="card-body scrollable">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                        <table class="table table-bordered data_table_video" data-order='[[ 0, "desc" ]]'>
                            <thead>
                                <tr role="row">
                                    <th style="width:35%;">Video Title</th>
                                    <th style="width:5%;">Thumbnail</th>
                                    <th style="width:15%;">Tools</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $video_tutorials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutorial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr role="row">
                                        <td><?php echo e($tutorial->video_title); ?></td>
                                        <td>
                                        <img src="<?php echo e(asset('assets/img/thumbnail_images/'.$tutorial->thumbnail_image)); ?>"
                                        width="80" height="60">
                                        </td>

                                        <td>
                 <button type="button" class="btn btn-success btn-sm btn-flat edit-video-btn"
                 data-toggle="modal" data-target="#video-update" value="<?php echo e($tutorial->id); ?>">
                                            <i class="fa fa-edit"></i></button>
                                            <br>
                                        </a>
                                        <form method="POST" action="<?php echo e(url('delete-video-tutorial/'.$tutorial->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                        <input name="_method" type="hidden" value="DELETE">
                                    <button type="button" class="btn btn-danger btn-sm btn-flat mb-2 show_confirm_blog"
                                    data-toggle="tooltip">
                                         <i class="fa fa-trash"></i>&nbsp;&nbsp;</button>
                                        </form>
                                        </td>
                                        
                                    </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </div>
                        </table>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
                
                <!-- /.col -->
            
            <!-- /.row -->
        
        <!-- /.container-fluid -->

<?php echo $__env->make('Backend.layouts.inc.add-video-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Backend.layouts.inc.update-video-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<script type="text/javascript">
     $('.show_confirm_blog').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: ``,
              text: "You Want To Delete Product?",
              icon: "warning",
              width: "200px",
              height:"120px",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });

</script>
<script>
   $('.data_table_video').DataTable({
    "scrollX": false,
    "scrollY": true,
    "ordering": false,

  });

  $(document).on('click','.edit-video-btn',function(e){
        e.preventDefault();

        var video_id=$(this).val();

        // alert(video_id);

        $.ajax({
            method:"GET",
            url:"edit-video/"+video_id,
            success:function(response){
                // console.log(response);
                $('#hidden_video_id').val(response.Video.id);
                $('#video_title').val(response.Video.video_title );
                $('#embade_code').val(response.Video.embade_code);
                $('#video_url').val(response.Video.video_url);
                $('#prod_id').val(response.Video.product_id);

            }
        });

      });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.backend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bdcleqiq/funcraftbytaiba.com/resources/views/Backend/video-tutorials.blade.php ENDPATH**/ ?>